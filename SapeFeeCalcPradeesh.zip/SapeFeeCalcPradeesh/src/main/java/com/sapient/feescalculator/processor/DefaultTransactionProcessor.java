package com.sapient.feescalculator.processor;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sapient.feescalculator.model.TransId;
import com.sapient.feescalculator.model.Transaction;
import com.sapient.feescalculator.model.TransactionType;

public class DefaultTransactionProcessor implements TransactionProcessor {

	private static final Double intradayFee = 10.0;
	
	
	public DefaultTransactionProcessor() {
	}

	@Override
	public void process(List<Transaction> transactions) {
		Map<TransId, Transaction> processedTrans = new HashMap<>();

		transactions.forEach(trans -> {
			TransId tid = createId(trans);
			Transaction record = null;
			if (!processedTrans.containsKey(tid)) {
				processedTrans.put(tid, trans);
				record = trans;
			} else {
				record = processedTrans.get(tid);
			}
			if (isIntraday(trans, transactions)) {
				record.setProcessedFee(new BigDecimal(record.getProcessedFee() + intradayFee));
			} else {
				record.setProcessedFee(new BigDecimal(intradayFee));
			}
		});
	}
	
	private BigDecimal calculateFee() {
		
	}

	private boolean isIntraday(Transaction transaction, List<Transaction> transactions) {
		for (Transaction t : transactions) {
			if (t.getClientId() == transaction.getClientId() && t.getSecurityId().equals(transaction.getSecurityId())
					&& t.getTransactionDate().equals(transaction.getTransactionDate())) {
				if ((t.getTransactionType() == TransactionType.Buy
						&& transaction.getTransactionType() == TransactionType.Sell)
						|| (t.getTransactionType() == TransactionType.Sell
								&& transaction.getTransactionType() == TransactionType.Buy)) {
					return true;
				}
			}
		}
		return false;
	}
	
	private TransId createId(Transaction t) {
		return new TransId(t.getClientId(), t.getTransactionType(), t.getTransactionDate(), t.isPriority());
	}

}

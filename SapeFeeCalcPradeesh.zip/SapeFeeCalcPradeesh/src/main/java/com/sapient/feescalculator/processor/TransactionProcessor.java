package com.sapient.feescalculator.processor;

import java.util.List;

import com.sapient.feescalculator.model.Transaction;

public interface TransactionProcessor {

	void process(List<Transaction> transactions);
}

package com.sapient.feescalculator.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Transaction {

	private int externalTransactionId;
	private int clientId;
	private String securityId;
	private TransactionType transactionType;
	private LocalDateTime transactionDate;
	private BigDecimal marketValue;
	private boolean priority;
	private BigDecimal processedFee;

	public Transaction() {
	}

	public Transaction(int externalTransactionId, int clientId, String securityId, TransactionType transactionType,
			LocalDateTime transactionDate, BigDecimal marketValue, boolean priority) {
		super();
		this.externalTransactionId = externalTransactionId;
		this.clientId = clientId;
		this.securityId = securityId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.marketValue = marketValue;
		this.priority = priority;
	}

	public int getExternalTransactionId() {
		return externalTransactionId;
	}

	public void setExternalTransactionId(int externalTransactionId) {
		this.externalTransactionId = externalTransactionId;
	}

	public int getClientId() {
		return clientId;
	}

	public void setClientId(int clientId) {
		this.clientId = clientId;
	}

	public String getSecurityId() {
		return securityId;
	}

	public void setSecurityId(String securityId) {
		this.securityId = securityId;
	}

	public TransactionType getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(TransactionType transactionType) {
		this.transactionType = transactionType;
	}

	public LocalDateTime getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(LocalDateTime transactionDate) {
		this.transactionDate = transactionDate;
	}

	public BigDecimal getMarketValue() {
		return marketValue;
	}

	public void setMarketValue(BigDecimal marketValue) {
		this.marketValue = marketValue;
	}

	public boolean isPriority() {
		return priority;
	}

	public void setPriority(boolean priority) {
		this.priority = priority;
	}

	public BigDecimal getProcessedFee() {
		return processedFee;
	}

	public void setProcessedFee(BigDecimal processedFee) {
		this.processedFee = processedFee;
	}

	@Override
	public String toString() {
		return "Transaction [externalTransactionId=" + externalTransactionId + ", clientId=" + clientId
				+ ", securityId=" + securityId + ", transactionType=" + transactionType + ", transactionDate="
				+ transactionDate + ", marketValue=" + marketValue + ", priority=" + priority + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + clientId;
		result = prime * result + (priority ? 1231 : 1237);
		result = prime * result + ((transactionDate == null) ? 0 : transactionDate.hashCode());
		result = prime * result + ((transactionType == null) ? 0 : transactionType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaction other = (Transaction) obj;
		if (clientId != other.clientId)
			return false;
		if (priority != other.priority)
			return false;
		if (transactionDate == null) {
			if (other.transactionDate != null)
				return false;
		} else if (!transactionDate.equals(other.transactionDate))
			return false;
		if (transactionType != other.transactionType)
			return false;
		return true;
	}

}

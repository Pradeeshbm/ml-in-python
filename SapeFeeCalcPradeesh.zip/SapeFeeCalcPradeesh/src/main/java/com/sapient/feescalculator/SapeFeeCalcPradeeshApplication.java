package com.sapient.feescalculator;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.sapient.feescalculator.exception.TransactionReaderException;
import com.sapient.feescalculator.exception.UnsupportedTransactionFileTypeException;
import com.sapient.feescalculator.model.Transaction;
import com.sapient.feescalculator.processor.DefaultTransactionProcessor;
import com.sapient.feescalculator.processor.TransactionProcessor;
import com.sapient.feescalculator.transreader.TransactionReader;
import com.sapient.feescalculator.transreader.TransactionReaderFactory;

@SpringBootApplication
public class SapeFeeCalcPradeeshApplication implements CommandLineRunner {
	
	@Autowired
	private TransactionProcessor transactionProcessor;

	public static void main(String[] args) {
		SpringApplication.run(SapeFeeCalcPradeeshApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Scanner s = new Scanner(System.in);
		System.out.println("Please enter transaction file path: ");
		String path = s.next();
		s.close();
		
		try {
			TransactionReader transReader = TransactionReaderFactory.createReader(path);
			List<Transaction> transList = transReader.readTransaction();
			transactionProcessor.process(transList);
		} catch (UnsupportedTransactionFileTypeException e) {
			System.out.println("The file typs is currently not supported. Please select only CSV file.");
		} catch (TransactionReaderException e) {
			System.out.println("Read failed!");
			e.printStackTrace();
		}
	}
	
	@Bean
	private TransactionProcessor transProcessor() {
		return new DefaultTransactionProcessor();
	}

}

package com.sapient.feescalculator.exception;

public class UnsupportedTransactionFileTypeException extends Exception {

	private static final long serialVersionUID = 1L;

	public UnsupportedTransactionFileTypeException() {
	}
	
	public UnsupportedTransactionFileTypeException(String msg) {
		super(msg);
	}

	public UnsupportedTransactionFileTypeException(String msg, Throwable t) {
		super(msg, t);
	}
}

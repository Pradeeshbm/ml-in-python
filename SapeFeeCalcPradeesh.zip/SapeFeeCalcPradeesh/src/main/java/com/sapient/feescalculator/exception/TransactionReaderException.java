package com.sapient.feescalculator.exception;

public class TransactionReaderException extends Exception {

	private static final long serialVersionUID = 1L;

	public TransactionReaderException() {
	}

	public TransactionReaderException(String msg, Throwable t) {
		super(msg, t);
	}

}

package com.sapient.feescalculator.transreader;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.core.io.FileSystemResource;

import com.sapient.feescalculator.exception.TransactionReaderException;
import com.sapient.feescalculator.model.Transaction;

public class CSVTransactionReader implements TransactionReader {

	private static final int LINE_TO_SKIP = 1;

	private FlatFileItemReader<Transaction> csvTransactionReader;
	private File transactionFile;

	public CSVTransactionReader(File transactionFile) {
		this.transactionFile = transactionFile;
	}

	@Override
	public List<Transaction> readTransaction() throws TransactionReaderException {
		List<Transaction> tList = null;
		
		try {
			csvTransactionReader = new FlatFileItemReader<>();
			csvTransactionReader.setResource(new FileSystemResource(transactionFile));
			csvTransactionReader.setLinesToSkip(LINE_TO_SKIP);
			csvTransactionReader.setLineMapper(new DefaultLineMapper<Transaction>() {
				{
					setLineTokenizer(new DelimitedLineTokenizer() {
						{
							setNames(attributes);
						}
					});
					setFieldSetMapper(new BeanWrapperFieldSetMapper<Transaction>() {
						{
							setTargetType(Transaction.class);
						}
					});
				}
			});
			tList = new ArrayList<>();
			Transaction t;
			while ((t = csvTransactionReader.read()) != null) {
				tList.add(t);
			}
		} catch (Exception e) {
			throw new TransactionReaderException("An error occured while reading the transaction file!", e);
		}
		return tList;
	}

}

package com.sapient.feescalculator.model;

public enum TransactionType {

	Buy, Sell, Deposit, Withdraw
}

package com.sapient.feescalculator.transreader;

import java.util.List;

import com.sapient.feescalculator.exception.TransactionReaderException;
import com.sapient.feescalculator.model.Transaction;

public interface TransactionReader {
	
	static final String[] attributes = { "externalTransactionId", "clientId", "securityId", "transactionType",
			"transactionDate", "marketValue", "priority" };
	
	List<Transaction> readTransaction() throws TransactionReaderException;
}

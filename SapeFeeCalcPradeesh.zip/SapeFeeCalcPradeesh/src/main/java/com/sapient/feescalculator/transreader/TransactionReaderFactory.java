package com.sapient.feescalculator.transreader;

import java.io.File;

import com.sapient.feescalculator.exception.UnsupportedTransactionFileTypeException;

public class TransactionReaderFactory {

	private TransactionReaderFactory() {
	}

	public static TransactionReader createReader(String transactionFile)
			throws UnsupportedTransactionFileTypeException {
		if (transactionFile.endsWith(".csv")) {
			return new CSVTransactionReader(new File(transactionFile));
		} else {
			throw new UnsupportedTransactionFileTypeException("The transaction file is not supported yet!");
		}
	}
}
